package com.natalia.ePrescription;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EPrescriptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
